#!/bin/bash
rm -rf .git
git init
git add .
git commit -m "Fresh start"
