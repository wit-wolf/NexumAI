cd c:\Users\werne\my-webapp\NexumAI
git add .
git commit -m "Update intranet app with frontend files and updated server configuration"
# git push origin <branch>  # Uncomment and update <branch> if you wish to push your changes.
